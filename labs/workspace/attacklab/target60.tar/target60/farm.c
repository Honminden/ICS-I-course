/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_400(unsigned x)
{
    return x + 3284633928U;
}

unsigned getval_381()
{
    return 3347667087U;
}

void setval_384(unsigned *p)
{
    *p = 3347664100U;
}

unsigned getval_364()
{
    return 2421733760U;
}

unsigned getval_296()
{
    return 3347663103U;
}

unsigned addval_459(unsigned x)
{
    return x + 1349496158U;
}

unsigned addval_247(unsigned x)
{
    return x + 3344434210U;
}

void setval_144(unsigned *p)
{
    *p = 1487453452U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_488()
{
    return 3678982537U;
}

unsigned getval_367()
{
    return 3465104128U;
}

unsigned getval_270()
{
    return 3767101591U;
}

unsigned addval_156(unsigned x)
{
    return x + 2425406089U;
}

void setval_168(unsigned *p)
{
    *p = 3523793289U;
}

unsigned addval_207(unsigned x)
{
    return x + 3378565513U;
}

void setval_234(unsigned *p)
{
    *p = 2497743176U;
}

unsigned addval_343(unsigned x)
{
    return x + 3465091627U;
}

unsigned getval_329()
{
    return 4006071945U;
}

void setval_484(unsigned *p)
{
    *p = 3676881545U;
}

void setval_454(unsigned *p)
{
    *p = 3286272328U;
}

unsigned getval_137()
{
    return 2425471625U;
}

unsigned getval_342()
{
    return 3281048009U;
}

unsigned getval_375()
{
    return 3381972617U;
}

void setval_236(unsigned *p)
{
    *p = 3523793291U;
}

unsigned getval_455()
{
    return 2497743176U;
}

unsigned addval_167(unsigned x)
{
    return x + 2378416809U;
}

void setval_277(unsigned *p)
{
    *p = 3767093421U;
}

unsigned addval_127(unsigned x)
{
    return x + 3531918989U;
}

unsigned getval_425()
{
    return 3224948360U;
}

unsigned addval_346(unsigned x)
{
    return x + 3224424073U;
}

void setval_352(unsigned *p)
{
    *p = 3375940105U;
}

unsigned getval_117()
{
    return 3375940233U;
}

unsigned addval_311(unsigned x)
{
    return x + 3676361097U;
}

void setval_490(unsigned *p)
{
    *p = 3281047937U;
}

unsigned getval_150()
{
    return 2445445520U;
}

unsigned getval_169()
{
    return 3286272360U;
}

unsigned addval_123(unsigned x)
{
    return x + 3380924813U;
}

unsigned addval_111(unsigned x)
{
    return x + 3769190625U;
}

unsigned getval_136()
{
    return 2430635336U;
}

void setval_267(unsigned *p)
{
    *p = 3525365401U;
}

void setval_389(unsigned *p)
{
    *p = 3676881545U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
